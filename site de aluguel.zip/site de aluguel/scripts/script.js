document.querySelector(".hamburger").addEventListener("click", () =>
    document.querySelector("#pp").classList.toggle("show-menu")

     
);